COMMAND LINE
============
javac com/clientserver/*.java
java com.clientserver.FileServer files
java com.clientserver.Client