COMMAND LINE
============
javac com/linecount/LineCounts.java
java com.linecount.LineCounts file1.txt file2.txt file3.txt file4.txt
