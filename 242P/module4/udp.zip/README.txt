COMMANDS
========
javac com/udp/*.java
java com.udp.UdpServer files
java com.udp.UdpClient
