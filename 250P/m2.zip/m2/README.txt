Systems Used
============
Node Version: v16.17.1
Browser: Firefox 106.0
Operating System: macOS Monterey Version 12.5
Architecture: ARM-based

How to Test The Webserver
=========================
Run `npm install`
Run `npm start`
Open browser and type `127.0.0.1` or `localhost` in the URL bar
Type stuff in the input bar and submit
