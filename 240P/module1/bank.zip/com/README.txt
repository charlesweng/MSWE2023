1. make sure you are 1 directory above "com"
2. javac com/bank/*.java
3. java com.bank.Bank
